<?php
$user = "root";
$password = "rootpass";
$database = "example_database";
$table = "todo_list";
try {

  $db = new PDO("mysql:host=mariadb;dbname=$database", $user, $password);
  echo "<h2>TODO</h2><ol>"; 
  foreach($db->query("SELECT content FROM $table") as $row) {
    echo "<li>" . $row['content'] . "</li>";
  }
  echo "</ol>";

} catch (PDOException $e) {

  # create database and table in case it doesn't exist, before giving up
  try {
    $db = new PDO("mysql:host=mariadb", $user, $password);
    $db->query("CREATE DATABASE $database;");
    $db->query("CREATE TABLE $database.$table (item_id INT AUTO_INCREMENT,content VARCHAR(255),PRIMARY KEY(item_id))");
    $db->query("INSERT INTO $database.$table (content) VALUES ('My first item');");
    Header('Location: '.$_SERVER['PHP_SELF']);
  } catch (PDOException $e) {
    print "Error!: " . $e->getMessage() . "<br/>";
    die();
  }
}
